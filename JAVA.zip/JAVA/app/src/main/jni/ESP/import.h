#ifndef ESP_IMPORT_H
#define ESP_IMPORT_H

#include <jni.h>
#include <string>
#include <cstdlib>
#include <unistd.h>
#include <sys/mman.h>
#include <android/log.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <cerrno>
#include <sys/un.h>
#include <cstring>
#include <string>
#include <cmath>
#include "struct.h"

//====== Booleand =====\\

bool is360Alert = true;
bool isSkeleton = true;
bool isPlayerHead = true;
bool isPlayerBox = true;
bool isPlayerLine = true;
bool isPlayerHealth = true;
bool isPlayerName = true;
bool isPlayerDistance = true;
bool isPlayerWeapon = true;
bool isPlayerWeaponIcon = true;
bool isGrenadeWarning = true;
bool isVehicles = true;
bool isItems = true;
bool isLootBox = true;
bool isLootItems = true;
bool isRadar = true;
bool isPlayerUID = true;
bool isPlayerNation = true;
bool isPlayerTeamID = true;
bool isFightMode = true;
//bool isVisibility = true;

#endif //ESP_IMPORT_H
