// Hacks.h - SAFE VERSION (ESP & Visual Only)
#ifndef ESP_HACKS_H
#define ESP_HACKS_H

#include "socket.h"
#include "Color.h"
#include "items.h"
#include "backends/ModsLoader.h"
#include <algorithm>
#include <chrono>

Color clr, clrTeam, clrDist, clrHealth, clrText, clrDistance;
Options options{1, -1, -1, 3, false, false, 1, false, 200, 200, 200, 19, 19, -1, false}; // Keep only safe toggles
OtherFeature otherFeature{false, false, false, false};

int botCount, playerCount;
Response response;
Request request;

void DrawESP (ESP& esp, int screenWidth, int screenHeight) {
    // No Auth Checks here if auth is handled safely in Java/ModsLoader
    float mScaleY = screenHeight / 1080.0f;

    // --- WATERMARK BOTTOM CENTER ---
    esp.DrawTextName(Color(180, 0, 0, 255), "ZERO X CHEAT", Vec2(screenWidth / 2.0f, screenHeight - 25), 26 * mScaleY);

    if (clientD < 0) {
        esp.DrawText(Color(255, 0, 0, 180), "DAEMON NOT CONNECTED", Vec2(screenWidth / 2.0f, 80 * mScaleY), 22 * mScaleY);
        return;
    }

    request.ScreenHeight = screenHeight;
    request.ScreenWidth = screenWidth;
    request.options = options;
    request.otherFeature = otherFeature;
    request.Mode = InitMode;

    botCount = 0, playerCount = 0;

    if (clientD >= 0) {
        if (send((void *) &request, sizeof(request))) {
            if (receive((void *) &response) > 0 && response.Success) {
                
                float BoxSize = (mScaleY * 3.0f);
                float textsize = 18 * mScaleY;

                for (int i = 0; i < response.PlayerCount && i < maxplayerCount; i++) {
                    PlayerData Player = response.Players[i];
                    if (Player.isBot) botCount++; else playerCount++;

                    x = Player.HeadLocation.x;
                    y = Player.HeadLocation.y;
                    magic_number = (Player.Distance * response.fov);
                    if (magic_number < 0.1f) magic_number = 0.1f;

                    float namewidht = (screenWidth / 6.0f) / magic_number;
                    float pp2 = namewidht / 2.0f;
                    float my = (screenWidth / 1.38f) / magic_number;
                    float top = y - my + (screenWidth / 1.7f) / magic_number;
                    float bottom = Player.Bone.lAn.y + my - (screenWidth / 1.7f) / magic_number;

                    // Visibility Check Color
                    if (Player.isVisible) clr = Color(0, 255, 0, 255); // Solid Green
                    else clr = Color(255, 0, 0, 255); // Solid Red

                    if (Player.HeadLocation.z != 1.0f) {
                        if (x > -200 && x < screenWidth + 200) {
                            
                            // Skeleton
                            if (isSkeleton && Player.Bone.isBone) {
                                float skelThick = 2.5f;
                                esp.DrawLine(clr, skelThick, Player.Bone.neck, Player.Bone.cheast);
                                esp.DrawLine(clr, skelThick, Player.Bone.cheast, Player.Bone.pelvis);
                                esp.DrawLine(clr, skelThick, Player.Bone.neck, Player.Bone.lSh);
                                esp.DrawLine(clr, skelThick, Player.Bone.neck, Player.Bone.rSh);
                                esp.DrawLine(clr, skelThick, Player.Bone.lSh, Player.Bone.lElb);
                                esp.DrawLine(clr, skelThick, Player.Bone.rSh, Player.Bone.rElb);
                                esp.DrawLine(clr, skelThick, Player.Bone.lElb, Player.Bone.lWr);
                                esp.DrawLine(clr, skelThick, Player.Bone.rElb, Player.Bone.rWr);
                                esp.DrawLine(clr, skelThick, Player.Bone.pelvis, Player.Bone.lTh);
                                esp.DrawLine(clr, skelThick, Player.Bone.pelvis, Player.Bone.rTh);
                                esp.DrawLine(clr, skelThick, Player.Bone.lTh, Player.Bone.lKn);
                                esp.DrawLine(clr, skelThick, Player.Bone.rTh, Player.Bone.rKn);
                                esp.DrawLine(clr, skelThick, Player.Bone.lKn, Player.Bone.lAn);
                                esp.DrawLine(clr, skelThick, Player.Bone.rKn, Player.Bone.rAn);
                            }

                            // Box
                            if (isPlayerBox) {
                               esp.DrawLine(clr, BoxSize, Vec2(x + pp2, top), Vec2(x + namewidht, top));
                               esp.DrawLine(clr, BoxSize, Vec2(x - pp2, top), Vec2(x - namewidht, top));
                               esp.DrawLine(clr, BoxSize, Vec2(x + namewidht, top), Vec2(x + namewidht, top + pp2));
                               esp.DrawLine(clr, BoxSize, Vec2(x - namewidht, top), Vec2(x - namewidht, top + pp2));
                               esp.DrawLine(clr, BoxSize, Vec2(x + pp2, bottom), Vec2(x + namewidht, bottom));
                               esp.DrawLine(clr, BoxSize, Vec2(x - pp2, bottom), Vec2(x - namewidht, bottom));
                               esp.DrawLine(clr, BoxSize, Vec2(x - namewidht, bottom), Vec2(x - namewidht, bottom - pp2));
                               esp.DrawLine(clr, BoxSize, Vec2(x + namewidht, bottom), Vec2(x + namewidht, bottom - pp2));
                            }

                            // Line
                            if (isPlayerLine) {
                                esp.DrawLine(clr, 2.5f, Vec2(screenWidth / 2.0f, 120), Vec2(x, top - 25));
                            }

                            // Health Bar
                            if (isPlayerHealth) {
                                float hl = std::max(screenWidth / 70.0f, mx);
                                Color ch = (Player.Health < 25) ? Color(255, 0, 0, 255) : (Player.Health < 50 ? Color(255, 165, 0, 255) : Color(0, 255, 0, 255));
                                if (Player.Health == 0) esp.DrawText(Color(255, 0, 0, 255), "Knocked", Vec2(x, top - 12), textsize);
                                else esp.DrawFilledRect(ch, Vec2(x - hl, top - 18), Vec2(x - hl + (2 * hl) * Player.Health / 100.0f, top - 14));
                            }

                            // Name
                            if (isPlayerName) {
                                char safeName[64]; memset(safeName, 0, 64);
                                if (Player.isBot) strcpy(safeName, "BOT");
                                else {
                                    decodePlayerName(Player.PlayerNameByte, safeName);
                                    if (strlen(safeName) == 0) strcpy(safeName, "Player");
                                }
                                esp.DrawName(Color(255, 255, 0, 255), safeName, Vec2(x, bottom + 10), textsize);
                            }

                            // Distance
                            if (isPlayerDistance) {
                                char distTxt[32]; sprintf(distTxt, "%0.0f m", Player.Distance);
                                esp.DrawText(Color(255, 255, 255, 255), distTxt, Vec2(x, bottom + 28), textsize);
                            }
                        }
                    }
                }
            }
        }
    }

    // Enemy Counter
    if (clientD >= 0) {
        float centerX = screenWidth / 2.0f;
        float startY = 35.0f;
        float boxW = 110.0f * mScaleY;
        float boxH = 55.0f * mScaleY;
        float radius = 25.0f * mScaleY;

        esp.DrawFilledRoundRect(Color(0, 0, 0, 220), Vec2(centerX - boxW, startY), Vec2(centerX + boxW, startY + boxH), radius);
        esp.DrawLine(Color(255, 255, 255, 200), 1.5f, Vec2(centerX, startY + 10), Vec2(centerX, startY + boxH - 10));

        char eTxt[16], bTxt[16];
        sprintf(eTxt, "%d", playerCount);
        sprintf(bTxt, "%d", botCount);

        esp.DrawText(Color(0, 255, 0, 255), eTxt, Vec2(centerX - boxW/2, startY + boxH/2 + 11 * mScaleY), 30 * mScaleY);
        esp.DrawText(Color(255, 50, 150, 255), bTxt, Vec2(centerX + boxW/2, startY + boxH/2 + 11 * mScaleY), 30 * mScaleY);
    }
}
#endif // ESP_HACKS_H